package com.example.datanucleus.dao;

import java.util.List;

public interface CategoryDao {
	
	public List<Category> getCategory();
}

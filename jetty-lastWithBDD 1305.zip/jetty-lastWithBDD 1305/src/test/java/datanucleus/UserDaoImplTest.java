package datanucleus;

public class UserDaoImplTest {

}

package com.example.datanucleus.dao;

import java.util.List;

public interface PictureDao {
	public List<Picture> getPicture();
}
